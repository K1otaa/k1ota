﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice.Interface
{
    public interface Auth_Interface
    {
        bool IsAuth(string Login, string Password);
    }
}
