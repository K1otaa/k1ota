﻿using Practice.db_context;
using Practice.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice.logic
{
    public class Auth_logic:Auth_Interface
    {
        DropTableEntities db = new DropTableEntities();
        public bool IsAuth(string Login, string Password) 
        {
            var user = db.Users.FirstOrDefault(u=>u.UserPass == Password && u.login == Login);
            if (user != null)
            {
                new DataGrid().Show();
                return true;
            }
            return false;
        }

    }
}
