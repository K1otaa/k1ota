﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalApp.interfaces
{
    internal interface auth_logic
    {
        bool IsAuth(string Login, string Password);
    }
}
