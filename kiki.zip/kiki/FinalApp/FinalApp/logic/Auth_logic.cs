﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FinalApp.db_context;
using System.Data.Entity;
using System.Threading.Tasks;
using FinalApp.interfaces;


namespace FinalApp.logic
{
    public class Auth_logic : auth_logic
    {
        FinalApp dbContext = new FinalApp();
        public bool IsAuth(string Login, string Password)
        {
            var user = dbContext.users.FirstOrDefault(u => u.login == Login && u.password == Password);
            if (user != null)
            {
                return true;
            }
            return false;
        }
    }
}
